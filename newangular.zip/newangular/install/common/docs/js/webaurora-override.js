/********************************************
 * This code is only intended for library
 * developers looking to test the library
 * in Core2 before disting it. This code is
 * brittle and will be susceptible to
 * breaking if the internal structure of
 * core2.js changes and MUST NOT be used
 * outside of its intended purpose.
 *
 * Please do not share this code with other
 * teams.
 ********************************************/

function webAuroraOverride(metaProjects) {
  var modulesUnderTest = {};
  metaProjects.forEach(function(value) {
    var split = value.split("/");
    if (modulesUnderTest[split[0]] === undefined) {
      modulesUnderTest[split[0]] = {};
    }
    modulesUnderTest[split[0]][split[1]] = "//afsweb.ms.com/ms/dev/";
  });
  
  var WebAuroraEnvironment = MS.core.WebAuroraEnvironment.prototype;
  var Release = MS.core.Release;
  
  function isAModuleUnderTest (meta, project) {
    return modulesUnderTest[meta] && modulesUnderTest[meta][project];
  }
  
  function isLoadedFromAfsWeb (meta, project) {
    return (/\/\/afsweb[\/.]/).test(modulesUnderTest[meta][project]);
  }
  
  Module.makeModulePath = function (meta, project, release, appendSuffix) {
    if (isAModuleUnderTest(meta, project)) {
      
      var suffix = appendSuffix ? this.suffix : "";
      var incrPath = new Release(meta, project, release).incrPath().replace('/incr/', '/incr/' + (isLoadedFromAfsWeb(meta, project)?'install/':'') + 'common/');
      return modulesUnderTest[meta][project] + incrPath + release + suffix;
    }
    return WebAuroraEnvironment.makeModulePath.apply(this, arguments);
  };
  
  Module.makeModuleBasePath = Module.makePath = function (meta, project, release) {
    if (isAModuleUnderTest(meta, project)) {
      return modulesUnderTest[meta][project] + new Release(meta, project, release).releasePath() + (isLoadedFromAfsWeb(meta, project)?'install/common/':'');
    }
    return WebAuroraEnvironment.makeModuleBasePath.call(this, meta, project, release);
  };
};