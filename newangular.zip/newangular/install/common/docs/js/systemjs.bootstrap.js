(function (global) { 
    /**
     * Notice the chain of Promises, the order in which we load the libraries does matter.
     */
    Promise.resolve()
        .then(function () {
            return System.import('core-js');
        })
        .then(function () {
            return Promise.all([
                System.import('zone.js'),
                System.import('moment'),
                System.import('ms/msjs/bootstrap-theme/2017.05.15-2/msdark')
              
                /* Load here additional libraries required. 
                * System.import('module-name')
                *
                * Don't forget to add the library in the following files:
                * - systemjs.config.js
                * - systemjs.spec.boostrap.js
                * - systemjs.spec.config.js
                * - Gruntfile.js
                */
            ]);
        })
        .then(function () {
            return System.import('rxjs/Rx');
        })
        .then(function () {
            // All the AngularJS files need to be resolved before importing the application files.
            return Promise.all(window.ngPackageNames.map(function (pkgName) { return System.import('@angular/' + pkgName); }));
        })
        .then(function () {
            return System.import('ng2-bootstrap');
        })
        .then(function () {
            // Load the application once the dependencies have been resolved, but only when not running WebAurora Concat (this
            // prevents the application resources from being concatenated which is necessary at the moment due to problems with
            // SystemJS running correctly within the concatenated code).
            if (!global.__isRunningWebAuroraConcat) {
                return System.import('app');
            }
        })
        .then(function () {
            // The ts compiler bundles the app logic under the "main" module, so the bootstrap to be called explicitly:
            // System.register("main", ["@angular/platform-browser-dynamic", "app.module"], callback)
            if (!global.__isRunningWebAuroraConcat) {
                return System.import('main');
            }
        })
        .then(function () {
            console.log("done");
        })
        .catch(function (err) {
            console.error(err);
        });
})(this);