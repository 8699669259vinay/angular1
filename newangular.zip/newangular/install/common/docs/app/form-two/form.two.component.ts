import { Component, OnInit, ViewChild } from '@angular/core';
import { newlistService  } from './../services/newlist.service';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'form-two',
  template: '<div class="panel panel-default"><div class="panel-heading"><h4>Add a list</h4></div><div class="panel-body"><form #newCribForm="ngForm" (ngSubmit)="onCribSubmit(newCribForm.value)"><div class="form-group col-sm-4"><label for="address" class="">Address</label><input type="text" class="form-control" placeholder="Address" name="address" ngModel required></div><div class="form-group col-sm-4"><label for="price" class="">Price</label><input type="text" class="form-control" placeholder="Price" name="price" ngModel required></div><div class="form-group col-sm-4"><label for="property-type" class="">Property Type</label><select name="type" id="property-type" class="form-control" ngModel required><option *ngFor="let type of propertyTypes" [value]="type">{{ type }}</option></select></div><div class="form-group col-sm-6"><label for="description" class="">Description</label><input type="text" class="form-control" placeholder="Description" name="description" ngModel required></div><div class="form-group col-sm-2"><label for="beds" class="">Beds</label><input type="text" class="form-control" placeholder="Beds" name="bedrooms" ngModel required></div><div class="form-group col-sm-2"><label for="baths" class="">Baths</label><input type="text" class="form-control" placeholder="Baths" name="bathrooms" ngModel required></div><div class="form-group col-sm-2"><label for="sqft" class="">Sqft</label><input type="text" class="form-control" placeholder="Sqft" name="area" ngModel required></div><div class="form-group col-sm-12"><button class="btn btn-primary listing-button" type="submit">Add</button></div></form></div></div>',
  styles: ['']
})
export class formtwoComponent implements OnInit {
  @ViewChild('newCribForm') newCribForm: NgForm;
    propertyTypes: Array<string> = ['House', 'Attic', 'villa'];
  constructor(public newlistservice: newlistService) {  }
  ngOnInit () {}
  onCribSubmit(data : any): void
  { //console.log(data);
    this.newlistservice.addCrib( data) ;
    this.newCribForm.reset();
    }
}