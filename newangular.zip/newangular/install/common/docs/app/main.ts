import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

//import { form1Module } from './form-one.module';
//import { AppModule } from './app.module';
//import { CssPracModule } from './css-prac.module';
import { newlistingModule } from './newlisting.module';

declare var Module: any;
if ((<any>Module).isPreCompiled()) {
    enableProdMode();
}
//platformBrowserDynamic().bootstrapModule(form1Module);
//platformBrowserDynamic().bootstrapModule(AppModule);
//platformBrowserDynamic().bootstrapModule(CssPracModule);
platformBrowserDynamic().bootstrapModule(newlistingModule);