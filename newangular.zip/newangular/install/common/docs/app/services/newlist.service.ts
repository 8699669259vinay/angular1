import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
//import {Subject} from 'rxjs/subject';
import {Subject} from 'rxjs/subject';
//*subject is both observer and observable */
import 'rxjs/add/operator/map';

@Injectable() 

export class newlistService { 
    public newlistsubject = new Subject<any>();
    constructor(private http: Http) {}
        getallcribs() 
        {return this.http.get('data/cribs.json').map(res => res.json());}
        addCrib(data: any) { 
            data.image = 'default-image';
            this.newlistsubject.next(data);}
    
} 