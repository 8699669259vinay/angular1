import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms';

import { CssPracComponent }  from './css-temp-prac/cssprac.component';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule
  ],
  declarations: [
    CssPracComponent,
  ],
  bootstrap: [ CssPracComponent ]
})
export class CssPracModule { }