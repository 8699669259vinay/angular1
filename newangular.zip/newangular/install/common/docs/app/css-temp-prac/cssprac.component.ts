import { Component, VERSION } from '@angular/core';
import { NgModel } from '@angular/forms';
import { ButtonsModule } from 'ng2-bootstrap';

@Component({
  selector: 'my-app',
  template: '<title>Mywebsite</title><div id="container"><div id="header"><h1>My website</h1></div></div><div id="content"><div id="nav"><h1>Navigation</h1><ul><li><a class="selected" href="">Home</a></li><li><a class="selected" href="">About</a></li><li><a href="">Contact</a></li></ul></div><div id="main"><h1>Home Page</h1><p>sdsdsadsadsadsdsa</p><p>asdfsfsdfsdfsdfsdfsd</p><p>sadfsdfsadfasdfsafdsfsdfsd</p></div><div id="footer">&Copy ; 2017 Vinay.</div></div>',  
  styles: ['#footer,#header{padding:10px;color:#fff}body{background-color:#EEE;font-family:helvetica,arial,sans-serif}a{text-decoration:none;color:red}#container{background-color:#f5f5f5;width:800px;margin-left:auto;margin-right:auto}#header{background-color:#6cf;text-align:center}h1,h2,h3{margin:0}#content{padding:10px}#nav{float:left;width:180px}#nav .selected{font-weight:700}#nav ul{list-style-type:none;padding:0}#main{float:right;width:600px}#footer{clear:both;background-color:#999;text-align:right}']
  })

export class CssPracComponent {
   }