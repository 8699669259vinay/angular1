import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { Ng2BootstrapModule } from 'ng2-bootstrap';

import { AppComponent }       from './app1/app.component';
import { appRoutingProviders, routing } from './app1/app.routing';
import { RouteOneComponent } from './app1/route-one/route-one.component';
import { RouteTwoComponent } from './app1/route-two/route-two.component';


@NgModule({
    imports: [
        BrowserModule,
        routing,
        FormsModule,
        Ng2BootstrapModule.forRoot()
    ],
    declarations: [
        AppComponent,
        RouteOneComponent,
        RouteTwoComponent
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
