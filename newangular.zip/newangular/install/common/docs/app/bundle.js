var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
System.register("app1/app.component", ["@angular/core"], function (exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var core_1, AppComponent;
    return {
        setters: [
            function (core_1_1) {
                core_1 = core_1_1;
            }
        ],
        execute: function () {
            AppComponent = (function () {
                function AppComponent() {
                    this.tabs = [
                        { title: 'First Tab', active: true, link: "tab-one" },
                        { title: 'Second Tab', active: false, link: "tab-two" }
                    ];
                    this.singleModel = '1';
                    this.version = core_1.VERSION.full;
                }
                AppComponent.prototype.setActiveTab = function (tab) {
                    for (var _i = 0, _a = this.tabs; _i < _a.length; _i++) {
                        var tabRef = _a[_i];
                        tabRef.active = false;
                    }
                    tab.active = true;
                };
                return AppComponent;
            }());
            AppComponent = __decorate([
                core_1.Component({
                    moduleId: __moduleName,
                    selector: 'my-app',
                    template: '<div class="title">Angular version {{version}}</div><div class="container"><ul class="nav nav-tabs"><li *ngFor="let tab of tabs" (click)="setActiveTab(tab)" [ngClass]="{\'active\': tab.active}"><a routerLink="/{{tab.link}}" routerLinkActive="active">{{tab.title}}</a></li></ul><router-outlet></router-outlet></div>',
                    styles: ['.title,a{font-family:Arial,Helvetica,sans-serif}.title{font-size:40px;height:10%;width:100%;padding-top:20px;position:fixed;text-align:center}a{font-size:30px}.container{padding-top:10%}']
                }),
                __metadata("design:paramtypes", [])
            ], AppComponent);
            exports_1("AppComponent", AppComponent);
        }
    };
});
System.register("app1/route-one/route-one.component", ["@angular/core"], function (exports_2, context_2) {
    "use strict";
    var __moduleName = context_2 && context_2.id;
    var core_2, RouteOneComponent;
    return {
        setters: [
            function (core_2_1) {
                core_2 = core_2_1;
            }
        ],
        execute: function () {
            RouteOneComponent = (function () {
                function RouteOneComponent() {
                    this.status = { isopen: false };
                    this.items = ['The first choice!',
                        'And another choice for you.', 'but wait! A third!'];
                }
                RouteOneComponent.prototype.toggled = function (open) {
                    console.log('Dropdown is now: ', open);
                };
                return RouteOneComponent;
            }());
            RouteOneComponent = __decorate([
                core_2.Component({
                    moduleId: __moduleName,
                    selector: 'my-app',
                    template: '<div class="content"><div class="btn-group" dropdown [(isOpen)]="status.isopen" (onToggle)="toggled($event)"><button id="single-button" type="button" class="btn btn-primary" dropdownToggle [disabled]="disabled">Button dropdown <span class="caret"></span></button><ul dropdownMenu role="menu" aria-labelledby="single-button"><li *ngFor="let choice of items"><a class="dropdown-item" href="#">{{choice}}</a></li></ul></div></div>'
                }),
                __metadata("design:paramtypes", [])
            ], RouteOneComponent);
            exports_2("RouteOneComponent", RouteOneComponent);
        }
    };
});
System.register("app1/route-two/route-two.component", ["@angular/core"], function (exports_3, context_3) {
    "use strict";
    var __moduleName = context_3 && context_3.id;
    var core_3, RouteTwoComponent;
    return {
        setters: [
            function (core_3_1) {
                core_3 = core_3_1;
            }
        ],
        execute: function () {
            RouteTwoComponent = (function () {
                function RouteTwoComponent() {
                }
                return RouteTwoComponent;
            }());
            RouteTwoComponent = __decorate([
                core_3.Component({
                    moduleId: __moduleName,
                    selector: 'my-app',
                    template: '<div class="content">Hello!</div>'
                }),
                __metadata("design:paramtypes", [])
            ], RouteTwoComponent);
            exports_3("RouteTwoComponent", RouteTwoComponent);
        }
    };
});
System.register("app1/app.routing", ["@angular/router", "app1/route-one/route-one.component", "app1/route-two/route-two.component"], function (exports_4, context_4) {
    "use strict";
    var __moduleName = context_4 && context_4.id;
    var router_1, route_one_component_1, route_two_component_1, appRoutes, appRoutingProviders, routing;
    return {
        setters: [
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (route_one_component_1_1) {
                route_one_component_1 = route_one_component_1_1;
            },
            function (route_two_component_1_1) {
                route_two_component_1 = route_two_component_1_1;
            }
        ],
        execute: function () {
            appRoutes = [
                { path: 'tab-one', component: route_one_component_1.RouteOneComponent },
                { path: 'tab-two', component: route_two_component_1.RouteTwoComponent },
                { path: '**', component: route_one_component_1.RouteOneComponent }
            ];
            exports_4("appRoutingProviders", appRoutingProviders = []);
            exports_4("routing", routing = router_1.RouterModule.forRoot(appRoutes, { useHash: true }));
        }
    };
});
System.register("app.module", ["@angular/core", "@angular/forms", "@angular/platform-browser", "ng2-bootstrap", "app1/app.component", "app1/app.routing", "app1/route-one/route-one.component", "app1/route-two/route-two.component"], function (exports_5, context_5) {
    "use strict";
    var __moduleName = context_5 && context_5.id;
    var core_4, forms_1, platform_browser_1, ng2_bootstrap_1, app_component_1, app_routing_1, route_one_component_2, route_two_component_2, AppModule;
    return {
        setters: [
            function (core_4_1) {
                core_4 = core_4_1;
            },
            function (forms_1_1) {
                forms_1 = forms_1_1;
            },
            function (platform_browser_1_1) {
                platform_browser_1 = platform_browser_1_1;
            },
            function (ng2_bootstrap_1_1) {
                ng2_bootstrap_1 = ng2_bootstrap_1_1;
            },
            function (app_component_1_1) {
                app_component_1 = app_component_1_1;
            },
            function (app_routing_1_1) {
                app_routing_1 = app_routing_1_1;
            },
            function (route_one_component_2_1) {
                route_one_component_2 = route_one_component_2_1;
            },
            function (route_two_component_2_1) {
                route_two_component_2 = route_two_component_2_1;
            }
        ],
        execute: function () {
            AppModule = (function () {
                function AppModule() {
                }
                return AppModule;
            }());
            AppModule = __decorate([
                core_4.NgModule({
                    imports: [
                        platform_browser_1.BrowserModule,
                        app_routing_1.routing,
                        forms_1.FormsModule,
                        ng2_bootstrap_1.Ng2BootstrapModule.forRoot()
                    ],
                    declarations: [
                        app_component_1.AppComponent,
                        route_one_component_2.RouteOneComponent,
                        route_two_component_2.RouteTwoComponent
                    ],
                    bootstrap: [app_component_1.AppComponent]
                }),
                __metadata("design:paramtypes", [])
            ], AppModule);
            exports_5("AppModule", AppModule);
        }
    };
});
System.register("css-temp-prac/cssprac.component", ["@angular/core"], function (exports_6, context_6) {
    "use strict";
    var __moduleName = context_6 && context_6.id;
    var core_5, CssPracComponent;
    return {
        setters: [
            function (core_5_1) {
                core_5 = core_5_1;
            }
        ],
        execute: function () {
            CssPracComponent = (function () {
                function CssPracComponent() {
                }
                return CssPracComponent;
            }());
            CssPracComponent = __decorate([
                core_5.Component({
                    selector: 'my-app',
                    template: '<title>Mywebsite</title><div id="container"><div id="header"><h1>My website</h1></div></div><div id="content"><div id="nav"><h1>Navigation</h1><ul><li><a class="selected" href="">Home</a></li><li><a class="selected" href="">About</a></li><li><a href="">Contact</a></li></ul></div><div id="main"><h1>Home Page</h1><p>sdsdsadsadsadsdsa</p><p>asdfsfsdfsdfsdfsdfsd</p><p>sadfsdfsadfasdfsafdsfsdfsd</p></div><div id="footer">&Copy ; 2017 Vinay.</div></div>',
                    styles: ['#footer,#header{padding:10px;color:#fff}body{background-color:#EEE;font-family:helvetica,arial,sans-serif}a{text-decoration:none;color:red}#container{background-color:#f5f5f5;width:800px;margin-left:auto;margin-right:auto}#header{background-color:#6cf;text-align:center}h1,h2,h3{margin:0}#content{padding:10px}#nav{float:left;width:180px}#nav .selected{font-weight:700}#nav ul{list-style-type:none;padding:0}#main{float:right;width:600px}#footer{clear:both;background-color:#999;text-align:right}']
                }),
                __metadata("design:paramtypes", [])
            ], CssPracComponent);
            exports_6("CssPracComponent", CssPracComponent);
        }
    };
});
System.register("css-prac.module", ["@angular/core", "@angular/platform-browser", "@angular/forms", "css-temp-prac/cssprac.component"], function (exports_7, context_7) {
    "use strict";
    var __moduleName = context_7 && context_7.id;
    var core_6, platform_browser_2, forms_2, cssprac_component_1, CssPracModule;
    return {
        setters: [
            function (core_6_1) {
                core_6 = core_6_1;
            },
            function (platform_browser_2_1) {
                platform_browser_2 = platform_browser_2_1;
            },
            function (forms_2_1) {
                forms_2 = forms_2_1;
            },
            function (cssprac_component_1_1) {
                cssprac_component_1 = cssprac_component_1_1;
            }
        ],
        execute: function () {
            CssPracModule = (function () {
                function CssPracModule() {
                }
                return CssPracModule;
            }());
            CssPracModule = __decorate([
                core_6.NgModule({
                    imports: [
                        platform_browser_2.BrowserModule,
                        forms_2.FormsModule
                    ],
                    declarations: [
                        cssprac_component_1.CssPracComponent,
                    ],
                    bootstrap: [cssprac_component_1.CssPracComponent]
                }),
                __metadata("design:paramtypes", [])
            ], CssPracModule);
            exports_7("CssPracModule", CssPracModule);
        }
    };
});
System.register("form-one/hero", [], function (exports_8, context_8) {
    "use strict";
    var __moduleName = context_8 && context_8.id;
    var Hero;
    return {
        setters: [],
        execute: function () {
            Hero = (function () {
                function Hero() {
                }
                return Hero;
            }());
            exports_8("Hero", Hero);
        }
    };
});
System.register("form-one/mock-heroes", [], function (exports_9, context_9) {
    "use strict";
    var __moduleName = context_9 && context_9.id;
    var HEROES;
    return {
        setters: [],
        execute: function () {
            exports_9("HEROES", HEROES = [
                { id: 11, name: 'Mr. Nice' },
                { id: 12, name: 'Narco' },
                { id: 13, name: 'Bombasto' },
                { id: 14, name: 'Celeritas' },
                { id: 15, name: 'Magneta' },
                { id: 16, name: 'RubberMan' },
                { id: 17, name: 'Dynama' },
                { id: 18, name: 'Dr IQ' },
                { id: 19, name: 'Magma' },
                { id: 20, name: 'Tornado' }
            ]);
        }
    };
});
System.register("form-one/hero.service", ["@angular/core", "form-one/mock-heroes"], function (exports_10, context_10) {
    "use strict";
    var __moduleName = context_10 && context_10.id;
    var core_7, mock_heroes_1, HeroService;
    return {
        setters: [
            function (core_7_1) {
                core_7 = core_7_1;
            },
            function (mock_heroes_1_1) {
                mock_heroes_1 = mock_heroes_1_1;
            }
        ],
        execute: function () {
            HeroService = (function () {
                function HeroService() {
                }
                HeroService.prototype.getHeroes = function () {
                    return Promise.resolve(mock_heroes_1.HEROES);
                };
                // See the "Take it slow" appendix
                HeroService.prototype.getHeroesSlowly = function () {
                    var _this = this;
                    return new Promise(function (resolve) {
                        // Simulate server latency with 2 second delay
                        setTimeout(function () { return resolve(_this.getHeroes()); }, 2000);
                    });
                };
                return HeroService;
            }());
            HeroService = __decorate([
                core_7.Injectable(),
                __metadata("design:paramtypes", [])
            ], HeroService);
            exports_10("HeroService", HeroService);
        }
    };
});
System.register("form-one/form1.component", ["@angular/core", "form-one/hero.service"], function (exports_11, context_11) {
    "use strict";
    var __moduleName = context_11 && context_11.id;
    var core_8, hero_service_1, form1Component;
    return {
        setters: [
            function (core_8_1) {
                core_8 = core_8_1;
            },
            function (hero_service_1_1) {
                hero_service_1 = hero_service_1_1;
            }
        ],
        execute: function () {
            form1Component = (function () {
                function form1Component(heroService) {
                    this.heroService = heroService;
                    this.title = 'Tour of Heroes';
                }
                form1Component.prototype.getHeroes = function () {
                    var _this = this;
                    this.heroService.getHeroes().then(function (heroes) { return _this.heroes = heroes; });
                };
                form1Component.prototype.ngOnInit = function () {
                    this.getHeroes();
                };
                form1Component.prototype.onSelect = function (hero) {
                    this.selectedHero = hero;
                };
                return form1Component;
            }());
            form1Component = __decorate([
                core_8.Component({
                    selector: 'my-app',
                    template: "\n    <h1>{{title}}</h1>\n    <h2>My Heroes</h2>\n    <ul class=\"heroes\">\n      <li *ngFor=\"let hero of heroes\"\n        [class.selected]=\"hero === selectedHero\"\n        (click)=\"onSelect(hero)\">\n        <span class=\"badge\">{{hero.id}}</span> {{hero.name}}\n      </li>\n    </ul>\n    <hero-detail [hero]=\"selectedHero\"></hero-detail>\n  ",
                    styles: ["\n    .selected {\n      background-color: #CFD8DC !important;\n      color: white;\n    }\n    .heroes {\n      margin: 0 0 2em 0;\n      list-style-type: none;\n      padding: 0;\n      width: 15em;\n    }\n    .heroes li {\n      cursor: pointer;\n      position: relative;\n      left: 0;\n      background-color: #EEE;\n      margin: .5em;\n      padding: .3em 0;\n      height: 1.6em;\n      border-radius: 4px;\n    }\n    .heroes li.selected:hover {\n      background-color: #BBD8DC !important;\n      color: white;\n    }\n    .heroes li:hover {\n      color: #607D8B;\n      background-color: #DDD;\n      left: .1em;\n    }\n    .heroes .text {\n      position: relative;\n      top: -3px;\n    }\n    .heroes .badge {\n      display: inline-block;\n      font-size: small;\n      color: white;\n      padding: 0.8em 0.7em 0 0.7em;\n      background-color: #607D8B;\n      line-height: 1em;\n      position: relative;\n      left: -1px;\n      top: -4px;\n      height: 1.8em;\n      margin-right: .8em;\n      border-radius: 4px 0 0 4px;\n    }\n  "],
                    providers: [hero_service_1.HeroService]
                }),
                __metadata("design:paramtypes", [hero_service_1.HeroService])
            ], form1Component);
            exports_11("form1Component", form1Component);
        }
    };
});
System.register("form-one/hero-detail.component", ["@angular/core", "form-one/hero"], function (exports_12, context_12) {
    "use strict";
    var __moduleName = context_12 && context_12.id;
    var core_9, hero_1, HeroDetailComponent;
    return {
        setters: [
            function (core_9_1) {
                core_9 = core_9_1;
            },
            function (hero_1_1) {
                hero_1 = hero_1_1;
            }
        ],
        execute: function () {
            HeroDetailComponent = (function () {
                function HeroDetailComponent() {
                }
                return HeroDetailComponent;
            }());
            __decorate([
                core_9.Input(),
                __metadata("design:type", hero_1.Hero)
            ], HeroDetailComponent.prototype, "hero", void 0);
            HeroDetailComponent = __decorate([
                core_9.Component({
                    selector: 'hero-detail',
                    template: "\n    <div *ngIf=\"hero\">\n      <h2>{{hero.name}} details!</h2>\n      <div>\n        <label>id: </label>{{hero.id}}\n      </div>\n      <div>\n        <label>name: </label>\n        <input [(ngModel)]=\"hero.name\" placeholder=\"name\"/>\n      </div>\n    </div>\n  "
                }),
                __metadata("design:paramtypes", [])
            ], HeroDetailComponent);
            exports_12("HeroDetailComponent", HeroDetailComponent);
        }
    };
});
System.register("form-one.module", ["@angular/core", "@angular/platform-browser", "@angular/forms", "form-one/form1.component", "form-one/hero-detail.component"], function (exports_13, context_13) {
    "use strict";
    var __moduleName = context_13 && context_13.id;
    var core_10, platform_browser_3, forms_3, form1_component_1, hero_detail_component_1, form1Module;
    return {
        setters: [
            function (core_10_1) {
                core_10 = core_10_1;
            },
            function (platform_browser_3_1) {
                platform_browser_3 = platform_browser_3_1;
            },
            function (forms_3_1) {
                forms_3 = forms_3_1;
            },
            function (form1_component_1_1) {
                form1_component_1 = form1_component_1_1;
            },
            function (hero_detail_component_1_1) {
                hero_detail_component_1 = hero_detail_component_1_1;
            }
        ],
        execute: function () {
            form1Module = (function () {
                function form1Module() {
                }
                return form1Module;
            }());
            form1Module = __decorate([
                core_10.NgModule({
                    imports: [
                        platform_browser_3.BrowserModule,
                        forms_3.FormsModule
                    ],
                    declarations: [
                        form1_component_1.form1Component,
                        hero_detail_component_1.HeroDetailComponent
                    ],
                    bootstrap: [form1_component_1.form1Component]
                }),
                __metadata("design:paramtypes", [])
            ], form1Module);
            exports_13("form1Module", form1Module);
        }
    };
});
System.register("new-listing/newlist.component", ["@angular/core"], function (exports_14, context_14) {
    "use strict";
    var __moduleName = context_14 && context_14.id;
    var core_11, newlistComponent;
    return {
        setters: [
            function (core_11_1) {
                core_11 = core_11_1;
            }
        ],
        execute: function () {
            newlistComponent = (function () {
                function newlistComponent() {
                }
                newlistComponent.prototype.ngOnInit = function () { };
                return newlistComponent;
            }());
            newlistComponent = __decorate([
                core_11.Component({
                    selector: 'my-app',
                    template: '<nav class="navbar navbar-default"><div class="container-fluid"><a href="" class="navbar-brand">ng-listing</a></div></nav><div class="container"><form-two>wait...</form-two><new-listing>waiting..</new-listing></div>'
                }),
                __metadata("design:paramtypes", [])
            ], newlistComponent);
            exports_14("newlistComponent", newlistComponent);
        }
    };
});
System.register("services/newlist.service", ["@angular/core", "@angular/http", "rxjs/subject", "rxjs/add/operator/map"], function (exports_15, context_15) {
    "use strict";
    var __moduleName = context_15 && context_15.id;
    var core_12, http_1, subject_1, newlistService;
    return {
        setters: [
            function (core_12_1) {
                core_12 = core_12_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (subject_1_1) {
                subject_1 = subject_1_1;
            },
            function (_1) {
            }
        ],
        execute: function () {
            newlistService = (function () {
                function newlistService(http) {
                    this.http = http;
                    this.newlistsubject = new subject_1.Subject();
                }
                newlistService.prototype.getallcribs = function () { return this.http.get('data/cribs.json').map(function (res) { return res.json(); }); };
                newlistService.prototype.addCrib = function (data) {
                    data.image = 'default-image';
                    this.newlistsubject.next(data);
                };
                return newlistService;
            }());
            newlistService = __decorate([
                core_12.Injectable(),
                __metadata("design:paramtypes", [http_1.Http])
            ], newlistService);
            exports_15("newlistService", newlistService);
        }
    };
});
System.register("form-two/form.two.component", ["@angular/core", "services/newlist.service", "@angular/forms"], function (exports_16, context_16) {
    "use strict";
    var __moduleName = context_16 && context_16.id;
    var core_13, newlist_service_1, forms_4, formtwoComponent;
    return {
        setters: [
            function (core_13_1) {
                core_13 = core_13_1;
            },
            function (newlist_service_1_1) {
                newlist_service_1 = newlist_service_1_1;
            },
            function (forms_4_1) {
                forms_4 = forms_4_1;
            }
        ],
        execute: function () {
            formtwoComponent = (function () {
                function formtwoComponent(newlistservice) {
                    this.newlistservice = newlistservice;
                    this.propertyTypes = ['House', 'Attic', 'villa'];
                }
                formtwoComponent.prototype.ngOnInit = function () { };
                formtwoComponent.prototype.onCribSubmit = function (data) {
                    this.newlistservice.addCrib(data);
                    this.newCribForm.reset();
                };
                return formtwoComponent;
            }());
            __decorate([
                core_13.ViewChild('newCribForm'),
                __metadata("design:type", forms_4.NgForm)
            ], formtwoComponent.prototype, "newCribForm", void 0);
            formtwoComponent = __decorate([
                core_13.Component({
                    selector: 'form-two',
                    template: '<div class="panel panel-default"><div class="panel-heading"><h4>Add a list</h4></div><div class="panel-body"><form #newCribForm="ngForm" (ngSubmit)="onCribSubmit(newCribForm.value)"><div class="form-group col-sm-4"><label for="address" class="">Address</label><input type="text" class="form-control" placeholder="Address" name="address" ngModel required></div><div class="form-group col-sm-4"><label for="price" class="">Price</label><input type="text" class="form-control" placeholder="Price" name="price" ngModel required></div><div class="form-group col-sm-4"><label for="property-type" class="">Property Type</label><select name="type" id="property-type" class="form-control" ngModel required><option *ngFor="let type of propertyTypes" [value]="type">{{ type }}</option></select></div><div class="form-group col-sm-6"><label for="description" class="">Description</label><input type="text" class="form-control" placeholder="Description" name="description" ngModel required></div><div class="form-group col-sm-2"><label for="beds" class="">Beds</label><input type="text" class="form-control" placeholder="Beds" name="bedrooms" ngModel required></div><div class="form-group col-sm-2"><label for="baths" class="">Baths</label><input type="text" class="form-control" placeholder="Baths" name="bathrooms" ngModel required></div><div class="form-group col-sm-2"><label for="sqft" class="">Sqft</label><input type="text" class="form-control" placeholder="Sqft" name="area" ngModel required></div><div class="form-group col-sm-12"><button class="btn btn-primary listing-button" type="submit">Add</button></div></form></div></div>',
                    styles: ['']
                }),
                __metadata("design:paramtypes", [newlist_service_1.newlistService])
            ], formtwoComponent);
            exports_16("formtwoComponent", formtwoComponent);
        }
    };
});
System.register("new-listing/newlisting.component", ["@angular/core", "@angular/http", "services/newlist.service"], function (exports_17, context_17) {
    "use strict";
    var __moduleName = context_17 && context_17.id;
    var core_14, http_2, newlist_service_2, newlistingComponent;
    return {
        setters: [
            function (core_14_1) {
                core_14 = core_14_1;
            },
            function (http_2_1) {
                http_2 = http_2_1;
            },
            function (newlist_service_2_1) {
                newlist_service_2 = newlist_service_2_1;
            }
        ],
        execute: function () {
            newlistingComponent = (function () {
                function newlistingComponent(http, newlistService) {
                    this.http = http;
                    this.newlistService = newlistService;
                    // this.cribs = new Array<any>();
                }
                newlistingComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    this.newlistService.getallcribs()
                        .subscribe(function (data) { return _this.cribs = data; }, function (error) { return _this.error = error.statusText; });
                    this.newlistService.newlistsubject.subscribe(function (data) { return _this.cribs.push(data); });
                    //this.newlistService.newlistsubject.subscribe(data => console.log(data));
                    //this.http.get('data/cribs.json').map(res => res.json()).subscribe(data => console.log(data));
                    //this.http.get('data/cribs.json').subscribe(data => console.log(data));
                    //this.http.get('data/cribs.json').map(res => res.json()).subscribe(data => this.cribs = data);
                    //,error => this.error = error.statusText);
                    //***map is rxjs operator; observables is a way to handle values over a course of time***
                    //  this.extractObservable().subscribe(data => {
                    //     for (let item in data) {
                    //       this.cribs.push(item);
                    //     }
                    //   }, error => this.error = error.statusText);
                };
                return newlistingComponent;
            }());
            newlistingComponent = __decorate([
                core_14.Component({
                    selector: 'new-listing',
                    template: '<div *ngFor="let crib of cribs"><newreusable [crib]="crib" class="col-sm-3">..</newreusable></div>'
                }),
                __metadata("design:paramtypes", [http_2.Http,
                    newlist_service_2.newlistService])
            ], newlistingComponent);
            exports_17("newlistingComponent", newlistingComponent);
        }
    };
});
System.register("newlist.interface", [], function (exports_18, context_18) {
    "use strict";
    var __moduleName = context_18 && context_18.id;
    return {
        setters: [],
        execute: function () {
        }
    };
});
System.register("new-listing/newreusable.component", ["@angular/core"], function (exports_19, context_19) {
    "use strict";
    var __moduleName = context_19 && context_19.id;
    var core_15, newreusableComponent;
    return {
        setters: [
            function (core_15_1) {
                core_15 = core_15_1;
            }
        ],
        execute: function () {
            newreusableComponent = (function () {
                function newreusableComponent() {
                }
                newreusableComponent.prototype.ngOnInit = function () {
                    // let beds = this.crib.bedroom;
                    // make http request to get data
                };
                return newreusableComponent;
            }());
            __decorate([
                core_15.Input('crib'),
                __metadata("design:type", Object)
            ], newreusableComponent.prototype, "crib", void 0);
            newreusableComponent = __decorate([
                core_15.Component({
                    selector: 'newreusable',
                    template: '<div class="thumbnail"><img src="assets/images/{{ crib.image }}.jpg" alt=""><div class="caption"><div *ngIf="!crib.showDetails"><h4><span class="label label-primary">{{ crib.type}}</span></h4><h3><i class="glyphicon glyphicon-tag"></i> {{ crib.price | currency:\'USD\':true }}</h3><h4><i class="glyphicon glyphicon-tag"></i> {{ crib.address }}</h4><hr><button class="btn btn-sm btn-success" *ngIf="!crib.showdetails" (click)="crib.showdetails = !crib.showdetails">Details</button></div><div *ngIf="crib.showdetails"><div class="details"><h4><span class="label label-primary">Beds: {{crib.bedroom}} </span><span class="label label-primary">SqFt: {{crib.area}} </span><span class="label label-primary">Baths: {{crib.bathrooms}}</span></h4><p>crib description</p><hr><button class="btn btn-sm btn-danger" *ngIf="!crib.showdetails" (click)="crib.showdetails = !crib.showdetails">close</button></div></div></div></div>',
                    styles: ['.thumbnail{min-height:380px}.label{display:inline-block}']
                }),
                __metadata("design:paramtypes", [])
            ], newreusableComponent);
            exports_19("newreusableComponent", newreusableComponent);
        }
    };
});
System.register("newlisting.module", ["@angular/core", "@angular/platform-browser", "ng2-bootstrap", "@angular/forms", "@angular/http", "new-listing/newlist.component", "form-two/form.two.component", "new-listing/newlisting.component", "new-listing/newreusable.component", "services/newlist.service", "rxjs/add/operator/map"], function (exports_20, context_20) {
    "use strict";
    var __moduleName = context_20 && context_20.id;
    var core_16, platform_browser_4, ng2_bootstrap_2, forms_5, http_3, newlist_component_1, form_two_component_1, newlisting_component_1, newreusable_component_1, newlist_service_3, newlistingModule;
    return {
        setters: [
            function (core_16_1) {
                core_16 = core_16_1;
            },
            function (platform_browser_4_1) {
                platform_browser_4 = platform_browser_4_1;
            },
            function (ng2_bootstrap_2_1) {
                ng2_bootstrap_2 = ng2_bootstrap_2_1;
            },
            function (forms_5_1) {
                forms_5 = forms_5_1;
            },
            function (http_3_1) {
                http_3 = http_3_1;
            },
            function (newlist_component_1_1) {
                newlist_component_1 = newlist_component_1_1;
            },
            function (form_two_component_1_1) {
                form_two_component_1 = form_two_component_1_1;
            },
            function (newlisting_component_1_1) {
                newlisting_component_1 = newlisting_component_1_1;
            },
            function (newreusable_component_1_1) {
                newreusable_component_1 = newreusable_component_1_1;
            },
            function (newlist_service_3_1) {
                newlist_service_3 = newlist_service_3_1;
            },
            function (_2) {
            }
        ],
        execute: function () {
            newlistingModule = (function () {
                function newlistingModule() {
                }
                return newlistingModule;
            }());
            newlistingModule = __decorate([
                core_16.NgModule({
                    imports: [
                        platform_browser_4.BrowserModule,
                        forms_5.FormsModule,
                        //ButtonsModule,
                        ng2_bootstrap_2.Ng2BootstrapModule.forRoot(),
                        http_3.HttpModule
                    ],
                    declarations: [
                        newlist_component_1.newlistComponent,
                        form_two_component_1.formtwoComponent,
                        newlisting_component_1.newlistingComponent,
                        newreusable_component_1.newreusableComponent
                    ],
                    providers: [newlist_service_3.newlistService
                    ],
                    bootstrap: [newlist_component_1.newlistComponent]
                }),
                __metadata("design:paramtypes", [])
            ], newlistingModule);
            exports_20("newlistingModule", newlistingModule);
        }
    };
});
System.register("main", ["@angular/core", "@angular/platform-browser-dynamic", "newlisting.module"], function (exports_21, context_21) {
    "use strict";
    var __moduleName = context_21 && context_21.id;
    var core_17, platform_browser_dynamic_1, newlisting_module_1;
    return {
        setters: [
            function (core_17_1) {
                core_17 = core_17_1;
            },
            function (platform_browser_dynamic_1_1) {
                platform_browser_dynamic_1 = platform_browser_dynamic_1_1;
            },
            function (newlisting_module_1_1) {
                newlisting_module_1 = newlisting_module_1_1;
            }
        ],
        execute: function () {
            if (Module.isPreCompiled()) {
                core_17.enableProdMode();
            }
            //platformBrowserDynamic().bootstrapModule(form1Module);
            //platformBrowserDynamic().bootstrapModule(AppModule);
            //platformBrowserDynamic().bootstrapModule(CssPracModule);
            platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(newlisting_module_1.newlistingModule);
        }
    };
});
//# sourceMappingURL=bundle.js.map