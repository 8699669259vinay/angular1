export interface crib {
     id : number,
    type : string,
    price: number,
    address: string,
    area: number,
    bedroom : number,
    bathrooms: number,
    image: string
}