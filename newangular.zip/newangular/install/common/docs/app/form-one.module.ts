import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms';

import { form1Component }  from './form-one/form1.component';
import { HeroDetailComponent } from './form-one/hero-detail.component';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule
  ],
  declarations: [
    form1Component,
    HeroDetailComponent
  ],
  bootstrap: [ form1Component ]
})
export class form1Module { }
