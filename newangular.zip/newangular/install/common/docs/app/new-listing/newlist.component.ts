import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<nav class="navbar navbar-default"><div class="container-fluid"><a href="" class="navbar-brand">ng-listing</a></div></nav><div class="container"><form-two>wait...</form-two><new-listing>waiting..</new-listing></div>'
  //styles: ['']
})
export class newlistComponent implements OnInit {
  constructor() {  }
  ngOnInit () {}
}