import { Component, OnInit, Input } from '@angular/core';
import {crib} from './../newlist.interface';

@Component({
  selector: 'newreusable',
  template: '<div class="thumbnail"><img src="assets/images/{{ crib.image }}.jpg" alt=""><div class="caption"><div *ngIf="!crib.showDetails"><h4><span class="label label-primary">{{ crib.type}}</span></h4><h3><i class="glyphicon glyphicon-tag"></i> {{ crib.price | currency:\'USD\':true }}</h3><h4><i class="glyphicon glyphicon-tag"></i> {{ crib.address }}</h4><hr><button class="btn btn-sm btn-success" *ngIf="!crib.showdetails" (click)="crib.showdetails = !crib.showdetails">Details</button></div><div *ngIf="crib.showdetails"><div class="details"><h4><span class="label label-primary">Beds: {{crib.bedroom}} </span><span class="label label-primary">SqFt: {{crib.area}} </span><span class="label label-primary">Baths: {{crib.bathrooms}}</span></h4><p>crib description</p><hr><button class="btn btn-sm btn-danger" *ngIf="!crib.showdetails" (click)="crib.showdetails = !crib.showdetails">close</button></div></div></div></div>',
  styles: ['.thumbnail{min-height:380px}.label{display:inline-block}']
})

export class newreusableComponent implements OnInit {
    // @Input('crib') crib : any;
    @Input('crib') crib : crib;  // using interface
  constructor() {  }
  ngOnInit () {
     // let beds = this.crib.bedroom;
     // make http request to get data
  } 
}