import { Component, VERSION } from '@angular/core';
import { NgModel } from '@angular/forms';
import { ButtonsModule } from 'ng2-bootstrap';

type TabConfig = { title: string, active: boolean, link: string };

@Component({
  moduleId: module.id,
  selector: 'my-app',
  template: '<div class="title">Angular version {{version}}</div><div class="container"><ul class="nav nav-tabs"><li *ngFor="let tab of tabs" (click)="setActiveTab(tab)" [ngClass]="{\'active\': tab.active}"><a routerLink="/{{tab.link}}" routerLinkActive="active">{{tab.title}}</a></li></ul><router-outlet></router-outlet></div>',
  styles: ['.title,a{font-family:Arial,Helvetica,sans-serif}.title{font-size:40px;height:10%;width:100%;padding-top:20px;position:fixed;text-align:center}a{font-size:30px}.container{padding-top:10%}']
})

export class AppComponent {
  private tabs: Array<TabConfig> = [
    { title: 'First Tab', active: true, link: "tab-one" },
    { title: 'Second Tab', active: false, link: "tab-two" }
  ];
  public version: string;
  public singleModel: string = '1';

  constructor() {
    this.version = VERSION.full;
  }

  public setActiveTab(tab: TabConfig) {
    for (let tabRef of this.tabs) {
      tabRef.active = false;
    }
    tab.active = true;
  }
}
