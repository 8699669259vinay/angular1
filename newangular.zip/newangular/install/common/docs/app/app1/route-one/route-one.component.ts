import { Component } from '@angular/core';
import { DropdownModule } from 'ng2-bootstrap';

@Component({
  moduleId: module.id,
  selector: 'my-app',
  template: '<div class="content"><div class="btn-group" dropdown [(isOpen)]="status.isopen" (onToggle)="toggled($event)"><button id="single-button" type="button" class="btn btn-primary" dropdownToggle [disabled]="disabled">Button dropdown <span class="caret"></span></button><ul dropdownMenu role="menu" aria-labelledby="single-button"><li *ngFor="let choice of items"><a class="dropdown-item" href="#">{{choice}}</a></li></ul></div></div>'
})
export class RouteOneComponent {
  public status:{isopen:boolean} = {isopen: false};
  public items:Array<string> = ['The first choice!',
    'And another choice for you.', 'but wait! A third!'];
 
  public toggled(open:boolean):void {
    console.log('Dropdown is now: ', open);
  }
}
