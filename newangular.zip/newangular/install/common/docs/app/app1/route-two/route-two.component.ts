import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'my-app',
  template: '<div class="content">Hello!</div>'
})
export class RouteTwoComponent {
}
