import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
//import { ButtonsModule } from 'ng2-bootstrap';
import { Ng2BootstrapModule } from 'ng2-bootstrap';
import { FormsModule }   from '@angular/forms';

import { HttpModule }   from '@angular/http';

import { newlistComponent }  from './new-listing/newlist.component';
import {formtwoComponent} from './form-two/form.two.component';
import { newlistingComponent }  from './new-listing/newlisting.component';
import { newreusableComponent }  from './new-listing/newreusable.component';
import {newlistService} from './services/newlist.service';
import 'rxjs/add/operator/map';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    //ButtonsModule,
    Ng2BootstrapModule.forRoot(),
    HttpModule
  ],
  declarations: [
    newlistComponent,
    formtwoComponent,
    newlistingComponent,
    newreusableComponent
  ],
  providers: [ newlistService
  ],
  bootstrap: [ newlistComponent ]
})
export class newlistingModule { }