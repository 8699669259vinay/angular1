module.exports = function (config) {
    config.set({

        // RESTRICTION: plugins needed by karma for this build have to be required locally so they can be resolved using the project's package.json
        plugins: [
            require('karma-coverage'),
            require('karma-phantomjs-launcher'),
            require('karma-jasmine'),
            require('karma-spec-reporter'),
            require('karma-msconfig'),
            require('karma-chrome-launcher'),
        ],

        // base path that will be used to resolve all patterns (eg. files, exclude)
        basePath: '../build/main',

        // RESTRICTION: list of frameworks to use in the karma run, the final of which must be msconfig which fixes some pathing issues related to included files.
        frameworks: ['jasmine', 'msconfig'],

        // list of files / patterns to load in the browser
        files: [
            'http://toolkits.ms.com/ria/webaurora/2017.04.12-1/core2.system.js',
            { pattern: 'app/**/*.html', watched: false, included: false, served: true },
            { pattern: 'app/**/*.css', watched: false, included: false, served: true },
            { pattern: 'app/**/*.js', included: false, served: true },
            'js/systemjs.spec.config.js',
            'js/systemjs.spec.bootstrap.js'
        ],

        // server proxies
        proxies: {
            // This should be a toolkits proxy once angular.js/2.4.0 is available there
            '/afsweb': 'http://afsweb.ms.com:80',
            '/toolkits': 'http://toolkits.ms.com:80',
            '/app' : '/base/app' 
        },

        // the reporters to use
        reporters: ['spec', 'coverage'],

        // coverage pre-processor (istanbul instramentation) 
        preprocessors: {
            // exclude spec files and app-main.js from coverage report
            'app/**/!(*.spec|main|bundle|app\.module|app\.routing).js': ['coverage']
        },

        // coverage reporter configuration
        coverageReporter: {
            dir: 'coverage-results/coverage/karma',
            includeAllSources: true,
            reporters: [
                { type: 'html', subdir: 'coverage-html' },
                { type: 'text' },
                { type: 'text-summary' }
            ]
        },

        // spec reporter configuration
        specReporter: {
            maxLogLines: 5,         // limit number of lines logged per test 
            suppressErrorSummary: true,  // do not print error summary 
            suppressFailed: false,  // do not print information about failed tests 
            suppressPassed: false,  // do not print information about passed tests 
            suppressSkipped: true,  // do not print information about skipped tests 
            showSpecTiming: false // print the time elapsed for each spec 
        },

        // web server port
        port: 9876,

        // enable / disable colors in the output (reporters and logs)
        colors: true,

        // level of logging (LOG_DISABLE | LOG_ERROR | LOG_WARN | LOG_INFO | LOG_DEBUG )
        logLevel: config.LOG_INFO,

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: false,

        // RESTRICTION: use these browsers (only PhantomJS and Chrome are currently supported)
        browsers: [ /* 'Chrome' */ 'PhantomJS'],

        // continious integration mode is off
        singleRun: true,

        browserNoActivityTimeout: 20000

    });
};