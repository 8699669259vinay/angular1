# Angular 2 Install Test Project

The purpose of this project is to make it easier to verify that a new Angular 2 project works
within the Morgan Stanley environment. It achieves this by providing the steps that need to be
followed in order to test a new install, as well as the project itself acting as a ready made
template to be extended with the minimal of effort.

## Testing a library before it has been disted
- Run `msgrunt build:update-types` or `msgrunt build:ts-deps`
- Manually copy the d.ts files for the library being tested into `node_modules/{lib-name}`
- Modify the `index.html` file such that the `webAuroraOverride()` call includes an array of the
  meta/project(s) that is being installed, for example `[ "ria/ng2-file-upload" ]`
- Add suitable configuration to the `systemjs.config.js` file to include a mapping to the library
  being installed, for example:
```
  meta['ng2-file-upload'] = { format: 'amd'};
  var ng2fileUploadURI = Module.resolve('ria', 'ng2-file-upload', '1.2.0') + '/ng2-file-upload.umd.js'
  map['ng2-file-upload'] = ng2fileUploadURI;
```
- Modify the code within the project to use the newly installed library
- Run `msgrunt build:local` and fix any errors that occur
- Run the built application within a web browser and ensure that the installed library has been
  loaded from afsweb and that it is working as expected

## Testing a library after it has been disted and added to WebAurora

- Update `package.json` to include . For example:
```
    {
        "org": "ria",
        "module": "ng2-file-upload",
        "version": "1.2.0",
        "consolidate": false,
        "src": "common",
        "filter": [
            "**/*.d.ts"
        ],
        "dest": "node_modules/ng2-file-upload"
    },
```
- Update `index.html` to remove the call to `webAuroraOverride()`
- Also update the WebAurora version to the latest one within `index.html`
- Run `msgrunt build:update-types` or `msgrunt build:ts-deps` to bring in the disted types
- Run `msgrunt build:local` to build the application
- Run the built application within a web browser and ensure that the installed library has been
  loaded from toolkits.ms.com and that it is working as expected