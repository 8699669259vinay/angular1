import { Component, OnInit, Input } from '@angular/core';
import {crib} from './../newlist.interface';

@Component({
  selector: 'newreusable',
  templateUrl: 'newreusable.component.html',
  styleUrls: ['newreusable.component.css']
})

export class newreusableComponent implements OnInit {
    // @Input('crib') crib : any;
    @Input('crib') crib : crib;  // using interface
  constructor() {  }
  ngOnInit () {
     // let beds = this.crib.bedroom;
     // make http request to get data
  } 
}