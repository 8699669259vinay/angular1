import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: 'newlist.component.html'
  //styleUrls: ['newlist.component.css']
})
export class newlistComponent implements OnInit {
  constructor() {  }
  ngOnInit () {}
}