import { Component, OnInit } from '@angular/core';
//import { ButtonsModule } from 'ng2-bootstrap';
//import { cribs } from './../data/cribs';
import { Http, Response } from '@angular/http';
import { newlistService } from './../services/newlist.service'
//***above is injectable service so we need to inject this before we use***
//import 'rxjs/add/operator/map';
//**** rxjs is reactive extension to javascripts. It is a way to use observable in javascript applications */
//import 'rxjs/add/operator/catch';
//import { Observable } from "rxjs/Observable";

@Component({
  selector: 'new-listing',
  templateUrl: 'newlisting.component.html'
  // styleUrls: ['newlisting.component.css']
})
export class newlistingComponent implements OnInit {
  //cribs: Array<any> = cribs;  
  //--- working on http json so above commented
  cribs: Array<any>;
  error: string;
  constructor(private http: Http
    , private newlistService: newlistService)
  {
   // this.cribs = new Array<any>();
  }
  ngOnInit() {
      this.newlistService.getallcribs()
      .subscribe(data => this.cribs = data,error => this.error = error.statusText);
      this.newlistService.newlistsubject.subscribe(data => this.cribs.push(data));
    //this.newlistService.newlistsubject.subscribe(data => console.log(data));
    //this.http.get('data/cribs.json').map(res => res.json()).subscribe(data => console.log(data));
    //this.http.get('data/cribs.json').subscribe(data => console.log(data));
    //this.http.get('data/cribs.json').map(res => res.json()).subscribe(data => this.cribs = data);
    //,error => this.error = error.statusText);
  //***map is rxjs operator; observables is a way to handle values over a course of time***

  //  this.extractObservable().subscribe(data => {
  //     for (let item in data) {
  //       this.cribs.push(item);
  //     }
  //   }, error => this.error = error.statusText);
  }
    // extractObservable(): Observable<any[]> {
    //     return this.http.get('http://localhost:3000/data/cribs.json').map(this.extractData).catch((error: any) => Observable.throw(error.json().error || 'Server error'));
    // }
    // extractData(res: Response) {
    //     let body = res.json();
    //     return body || {};
    // }
}
