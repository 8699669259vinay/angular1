import { Component, VERSION } from '@angular/core';
import { NgModel } from '@angular/forms';
import { ButtonsModule } from 'ng2-bootstrap';

@Component({
  selector: 'my-app',
  templateUrl: 'cssprac.component.html',  
  styleUrls: ['css-prac.css']
  })

export class CssPracComponent {
   }