import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'my-app',
  templateUrl: 'route-two.component.html'
})
export class RouteTwoComponent {
}
