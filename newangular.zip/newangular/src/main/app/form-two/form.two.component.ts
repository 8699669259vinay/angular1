import { Component, OnInit, ViewChild } from '@angular/core';
import { newlistService  } from './../services/newlist.service';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'form-two',
  templateUrl: 'form.two.component.html',
  styleUrls: ['form.two.component.css']
})
export class formtwoComponent implements OnInit {
  @ViewChild('newCribForm') newCribForm: NgForm;
    propertyTypes: Array<string> = ['House', 'Attic', 'villa'];
  constructor(public newlistservice: newlistService) {  }
  ngOnInit () {}
  onCribSubmit(data : any): void
  { //console.log(data);
    this.newlistservice.addCrib( data) ;
    this.newCribForm.reset();
    }
}