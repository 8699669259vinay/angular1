/**
 * System configuration for Angular 2 samples
 * Adjust as necessary for your application needs.
 */
(function (global) {

    var map = {}, packages = {}, paths = {}, bundles = {}, meta = {}, paths = {};;

    var ngPackageNames = [
        'common',
        'compiler',
        'core',
        'forms',
        'http',
        'platform-browser',
        'platform-browser-dynamic',
        'router',
        'forms'
    ];

    meta['bootstrap-theme/*'] = {
        loader: 'ms',
        loaderConfig: {
            path: 'ria/bootstrap-theme'
        }
    };

    meta['*'] = {
        scriptLoad: true,
    };

    meta['app/*'] = {
        format: 'register',
        scriptLoad: true
    };
    packages['app'] = { main: 'main.app', defaultExtension: 'js' }
    map['app'] = 'base/app';

    // This should be the toolkits proxy once it is available there
    var angular2URI = Module.resolve("ria", "angular", "4.1.3")
        .replace(/\/\/(.*).ms.com\//, function (match, g1) { return '/' + g1 + '/'; })
        .replace(/http:/, '')
        + '/@angular';
    meta[angular2URI + "/*"] = { format: 'amd' };
    map['@angular'] = angular2URI;
    ngPackageNames.forEach(function (pkgName) {
        packages['@angular/' + pkgName] = { main: 'bundles/' + pkgName + '.umd.js' };
    });
    ngPackageNames.forEach(function (pkgName) {
        packages['@angular/' + pkgName + '/testing'] = { defaultExtension: 'js', format: 'amd' };
        map['@angular/' + pkgName + '/testing'] = angular2URI + '/' + pkgName + '/bundles/' + pkgName + '-testing.umd.js';
    });

    meta['rxjs/Rx'] = { format: 'amd'};
    paths['rxjs/Rx'] = Module.resolve('ria', 'rxjs', '5.3.0-ms1')+ '/ms/Rx.js';

    packages['zone.js'] = { defaultExtension: 'js', format: 'amd' };
    map['zone.js'] = Module.resolve('ria', 'zone.js', '0.6.25-ms1') + '/dist';
    
    meta['ng2-bootstrap'] = { format: 'amd'};
    paths['ng2-bootstrap'] = Module.resolve('ria', 'ng2-bootstrap', '1.3.1') + '/ng2-bootstrap.umd.js'

    meta['moment'] = { format: 'amd'  };
    paths['moment'] = Module.resolve('ria', 'moment.js', '2.10.6') + '/moment.min.js';

    meta['core-js'] = { format: 'amd'};
    paths['core-js'] = Module.resolve('ria', 'core-js', '2.4.1') + '/shim.min.js';

    meta['reflect-decorators'] = { format: 'amd' };
    paths['reflect-decorators'] = Module.resolve('ria', 'reflect-decorators', '0.1.10') + '/Reflect.min.js';

    /**
     * Add here the configuration for new libraries:
     * 
     * meta['library-name'] = {
     *   format: 'amd',
     *   scriptLoad: true
     * };
     * map['library-name'] = Module.resolve("library-meta", "library-name", "library-version") + '/path/to/js/file.js';
     *
     * Don't forget to also add the library in the following files:
     * - systemjs.boostrap.js
     * - systemjs.spec.boostrap.js
     * - systemjs.config.js
     * - Gruntfile.js
     */

    var config = {
        msOptions: {
            shim: {}
        },
        meta: meta,
        map: map,
        paths: paths,
        packages: packages
    }

    System.config(config);
})(this);

