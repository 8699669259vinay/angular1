//Do not modify this file, only if you need to import additional libraries. If that is the case follow the instructions below.
(function () {
    //Bootstrapping load
    var karmaLoadedFunction = window.__karma__.loaded;
    window.__karma__.loaded = function () { };
    Module.debugMode();
    Promise.resolve()
        .then(function () {
            return System.import('core-js');
        })
        .then(function () {
            return Promise.all([
                System.import('zone.js/zone'),
                System.import('moment'),
                System.import('ms/msjs/bootstrap-theme/2017.05.15-2/msdark')
                /**
                 * Load here additional libraries required. 
                 * System.import('module-name')
                 *
                 * Don't forget to add the library in the following files:
                 * - systemjs.boostrap.js
                 * - systemjs.config.js
                 * - systemjs.spec.config.js
                 * - Gruntfile.js
                 */
            ]);
        }).then(function () {
            return System.import('rxjs/Rx');
        }).then(function () {
            return Promise.all([
                System.import('zone.js/proxy'),
                System.import('zone.js/wtf'),
                System.import('zone.js/long-stack-trace-zone'),
                System.import('zone.js/sync-test'),
                System.import('zone.js/task-tracking'),
                System.import('zone.js/async-test'),
                System.import('zone.js/fake-async-test')
            ]);
        }).then(function () {
            return Promise.all([
                System.import('zone.js/jasmine-patch')
            ]);
        }).then(function () {
            function isSpecFile(path) {
                return path.slice(-8) === '.spec.js';
            }
            return Promise.all(
                Object.keys(window.__karma__.files).filter(isSpecFile).map(function (moduleName) {
                    return System.import(moduleName);
                })
            );
        }).then(function () {
            window.__karma__.loaded = karmaLoadedFunction;
            console.log('Running Tests.');
            window.__karma__.loaded();
        }).catch(function (error) {
            console.error(error.message);
            console.error(error.stack);
        });

})();