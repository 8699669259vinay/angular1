var express = require('express');
var proxy = require('express-http-proxy');
var livereload = require('connect-livereload');
var url = require('url');
var path = require('path');
var server = express();

server.use(livereload({
    port: 35729,
    include: ['index.html', '']
}));

server.use(express.static('../install/common/docs'));

// Uncomment this if you want to proxy a remote service layer

// server.use( '/my-remote-web-app', proxy( 'my-remote-domain.webfarm-dev.ms.com:1234', {
// 	forwardPath: function( req, res ){
// 		return forwardUrl = '/my-remote-web-app' + url.parse( req.url ).path;
// 	}
// } ) );

server.listen(3000, function () {
    console.log('Example app listening on port 3000!');
});