process.execArgv = [process.argv[0]];

module.exports = function (grunt) {


	var libraries = [
        'angular2/core',
        'angular2/compiler',
        'angular2/common',
		'angular2/forms',
        'angular2/http',
        'angular2/platform-browser',
        'angular2/platform-browser-dynamic',
        'angular2/router',
		'rxjs/rx',
		'ng2-bootstrap/ng2-bootstrap',
		'moment/moment',
		'core-js/shim',
		'zone.js/zone',
		'reflect-decorators/Reflect'
		/**
		 *  Add here the configuration for new libraries:
         * 
         * 'library-name/package-name.js';
         *
         * Don't forget to add the library in the following files:
         * - systemjs.boostrap.js
		 * - systemjs.config.js
         * - systemjs.spec.boostrap.js
		 * - systemjs.spec.config.js
		 */
    ];

	libraries.forEach(function (package) {
		grunt.file.write('./main/noop/' + package + '.js', '');
	});
	
	var isWin = /^win/.test(process.platform),
		platformPrefix = (isWin ? "M:" : "//ms"),
		platformCwd = (isWin ? "." : "//");

	// INITIALIZE: COMMON MSGRUNT BUILD OBJECT
	var msgrunt = require('msgrunt')(grunt, {
			
		ng2_inline: {
			default: {
                expand: true,
                nonull: true,
                src: '<%= pkg.ms.build.src.dir %>/app/**/*.ts',
                options: {
                    compress: true,
                    relative: true
                }
            }
		},
		
		watch: {
			local: {
				files: ["main/**/*"],
				tasks: ["express:dev:stop", "build:watch", "express:dev"],
				options: {
					spawn: false,
					livereload: true
				}
			},
			fast: {
				files: ["main/**/*"],
				tasks: ["express:dev:stop", "build:fastwatch", "express:dev"],
				options: {
					spawn: false,
					livereload: true
				}
			}
		},

		clean: {
			types: {
				expand: true,
				cwd: "node_modules",
				src: [ '**/*' ]
			},
			watched: {
				expand: true,
				cwd: "<%= pkg.ms.install.docs.dir %>",
				src: [
					"*",
					"!node_modules",
					"!app",
					"app/*"
				]
			}
		},

		// symlink: {
		// 	node_modules: {
		// 		files: [{
		// 			src: ['node_modules'],
		// 			dest: '<%= pkg.ms.build.dir %>/node_modules'
		// 		}]
		// 	}
		// },

		copy: {
			webapp: {
				cwd: "<%= pkg.ms.build.dir %>/<%= pkg.ms.src.dir %>",
				src: ["**/*", "!js/systemjs.spec.bootstrap.js", "!js/systemjs.spec.config.js"]
			},
			files:{
				cwd:'./node_modules',
				src:'**/**',
				dest:'<%= pkg.ms.build.dir %>/node_modules',
				expand: true
			}
		},

		ts: {
			build: {
				tsconfig: {
					passThrough: true,
					tsconfig: "<%= pkg.ms.build.dir %>/tsconfig.json"
				},
				options: {
                    compiler: "<%= require.resolve({ module: 'typescript', file: 'bin/tsc', rootPath: true }) %>",
					fast: "never"
				}
			},
			buildTests: {
				tsconfig: {
					passThrough: true,
					tsconfig: "<%= pkg.ms.build.dir %>/tsconfig-tests.json"
				},
				options: {
                    compiler: "<%= require.resolve({ module: 'typescript', file: 'bin/tsc', rootPath: true }) %>",
					fast: "never"
				}
			}
		},

		express: {
			options: {
				cmd: process.execPath,
				opts: [process.argv[0]]
			},
			dev: {
				options: {
					script: "server.js"
				}
			}
		},

		run: {
			server: {
				options: {
					wait: false,
					failOnError: true,
				},
				exec: 'node server.js'
			}
		},
		
		replace: {
			defaultExtension: {
				options: {
					patterns: [
						{
							match: /defaultExtension:\s*["']js["']/g,
							replacement: "defaultExtension: 'min.js'"
						}
					]
				},
				files: [
					{
						expand: true,
						flatten: true,
						src: "<%= pkg.ms.install.docs.dir %>/js/*.min.js",
						dest: "<%= pkg.ms.install.docs.dir %>/js/"
					}
				]
			},
			moduleidReplacement: {
			
				options: {
					patterns: [
						{
							match: 'module.id',
							replacement: "__moduleName"
						}
					],
					 usePrefix: false
				},
				files: [
					{
						cwd: "../install",
						expand: true,
						src: ["<%= pkg.ms.install.docs.dir %>/**/*.js"]
					},		
					{
						cwd: "<%= pkg.ms.build.dir %>",
						expand: true,
						src: ["<%= pkg.ms.build.dir %>/**/*.js"]
					}
				]
			},
			insertDebuggingFix: {
				options: {
					patterns: [
						{
							match: '<title>Angular 2 Template project</title>',
							replacement: "<title>Angular 2 Template project</title>\n<script type=\"text/javascript\">window.history.pushState = null;</script>"
						}
					],
					 usePrefix: false
				},
				files: [
					{
						expand: true,
						src: "<%= pkg.ms.install.docs.dir %>/index.debug.html"
					}
				]
			},
			createIndexDebug: {
				options: {
					patterns: [
						{
							match: /index\.([^\.]+)\.min\./g,
							replacement: "index.$1."
						}
					],
					usePrefix: false
				},				
				files: [
					{
						expand: true,
						src: "<%= pkg.ms.install.docs.dir %>/index.html",
						dest: "<%= pkg.ms.install.docs.dir %>",
						rename: function(dest, src) {
							return src.replace(/index.html/,'index.debug.html');
						}
					}
				]
			}			
		},
		uglify: {
			bundle: {
				options: {
					sourceMapIn: "<%= pkg.ms.install.dest.dir %>/app/bundle.js.map",
					sourceMap: true,
					sourceMapName: "<%= pkg.ms.install.dest.dir %>/app/bundle.min.js.map",
					screwIE8: true,
					mangle: {
						screw_ie8: true
					}
				},
				src: [
					"app/bundle.js"
				],
				expand: true,
				cwd: "<%= pkg.ms.install.dest.dir %>",
				dest: "<%= pkg.ms.install.dest.dir %>",
				ext: ".min.js",
            	extDot: "last"
			}
		}
	});
	
	grunt.registerTask('grunt-templates-inline', ['ng2_inline']);
	grunt.registerTask('buildTests', ['ts:buildTests']);

	// REGISTER: BUILD TASKS
	msgrunt.registerBuilds();
   	// RETURN: AND RUN
};